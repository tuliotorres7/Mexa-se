<label class="{{ $class ?? null }} submit">
    
    {!! Form::submit($input)!!}
</label>