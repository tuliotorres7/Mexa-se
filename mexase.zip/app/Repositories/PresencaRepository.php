<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface PresencaRepository.
 *
 * @package namespace App\Repositories;
 */
interface PresencaRepository extends RepositoryInterface
{
    //
}
