<?php $__env->startSection('css-view'); ?>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('js-view'); ?>

<script>
    function createQrCode()
    {
        
        var userInput = document.getElementById('valor').value;

        var qrcode = new QRCode("qrcode", {
            text: userInput,
            width: 256,
            height: 256,
            colorDark: "black",
            colorLight: "white",
            correctLevel : QRCode.CorrectLevel.H
        });
    }
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('conteudo-view'); ?>

    <div class="row">
    <div class="col">
    <label class="form-padrao">
        <span id="geraQr"> ID-Cliente:</span> 
    <input type="text" id="valor" value="">
    </label>
    <button onClick="createQrCode()">Gerar QR Code</button>
    
    </div>
    </div>
    <div id="qrcode"></div>


    
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/user/dashboard.blade.php ENDPATH**/ ?>