<?php $__env->startSection('css-view'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js-view'); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('conteudo-view'); ?>
    <?php if(session('success')): ?>
        <h3><?php echo e(session('success')['messages']); ?></h3>
    <?php endif; ?>
 
    <?php echo Form::open(['route' => 'user.store', 'method' => 'post','class'=>  'form-padrao']); ?>

    <div class="row">        
<div class="col">
    <?php echo $__env->make('templates.formulario.input',['input' => 'cpf', 'attributes'=>['placeholder' => 'CPF']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="col">
    <?php echo $__env->make('templates.formulario.input',['input' => 'nome', 'attributes'=>['placeholder' => 'Nome']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
</row>
<div class="row">  
    <div class="col">
    <?php echo $__env->make('templates.formulario.input',['input' => 'email', 'attributes'=>['placeholder' => 'E-mail']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
<div class="col">
        <?php echo $__env->make('templates.formulario.password',['input' => 'password', 'attributes'=>['placeholder' => 'Senha']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div></div>
        <div class="row">    
        <div class="col">
    <?php echo $__env->make('templates.formulario.input',['input' => 'cref', 'attributes'=>['placeholder' => 'CREF']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
    </div>
    <div class="col">   
        <?php echo $__env->make('templates.formulario.submit',['input' => 'Cadastrar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
</div>
</div>
        <?php echo Form::close(); ?>

        
<div class="row">
<div class=table-responsive-xl>
    <table class="table table-hover">
        <thead>
            <tr>
                <th> id </th>
                <th> CPF </th>
                <th> Nome </th>
                <th> Email </th>
                <th> CREF </th>
                <th> Status </th>
                <th> Permissão </th>

                <th> Opção</th>
            </tr>
        </thead>
        <tbody>
            <?php $__currentLoopData = $users; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $user): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <tr>
                <td><?php echo e($user -> id); ?></id>
                <td><?php echo e($user -> formattedCpf); ?></td>
                <td><?php echo e($user -> nome); ?></td>
                <td><?php echo e($user -> email); ?></td>
                <td><?php echo e($user -> cref); ?></td>
                <td><?php echo e($user -> status); ?></td>
                <td><?php echo e($user -> permission); ?></td>
                <td>
                    <?php echo Form::open(['route'=> ['user.destroy',$user->id],'method' => 'DELETE']); ?>

                    <?php echo Form::submit('Remover'); ?>

                    <?php echo Form::close(); ?>

                </td>
            </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        </tbody>
    </table>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/user/index.blade.php ENDPATH**/ ?>