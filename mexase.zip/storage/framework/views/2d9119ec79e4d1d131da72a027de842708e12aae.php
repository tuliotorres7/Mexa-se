<?php $__env->startSection('conteudo-view'); ?>
<?php if(session('success')): ?>
        <h3><?php echo e(session('success')['messages']); ?></h3>
<?php endif; ?>

<?php echo Form::open(['route' => 'cliente.store', 'method' => 'post','class'=>  'form-padrao']); ?>

<div class="row">        
<div class="col">
        <?php echo $__env->make('templates.formulario.input',['input' => 'nome', 'attributes'=>['placeholder' => 'Nome']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>  
<div class="col">

        <?php echo $__env->make('templates.formulario.select',['label' => 'Instrutor', 'select' =>'user_id', 'data'=> $user_list ?? '' , 'attributes'=>['placeholder' => 'Instrutor']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
        <div class="row">        
<div class="col">
        <?php echo $__env->make('templates.formulario.input',['input' => 'telefone', 'attributes'=>['placeholder' => 'Telefone']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>  
<div class="col">
<?php echo $__env->make('templates.formulario.input',['input' => 'endereco', 'attributes'=>['placeholder' => 'Endereco']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
        <div class="row">        
<div class="col">
<label class>
<span>Dia de Inicio</span>
    <input type="date" name="dataInicio">
</label>
        </div>  
        <div class="col">
        <?php echo $__env->make('templates.formulario.input',['input'=>'obs','label' => 'Observação', 'attributes'=>['placeholder' => 'Observações']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
        <div class="row">        
        <div class="col">
        <?php echo $__env->make('templates.formulario.submit',['input' => 'Cadastrar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
        
       
        


        <?php echo Form::close(); ?>



<div class="row">
<div class=table-responsive-xl>
<table class="table table-hover">
<thead>
    <tr>
        <th>#</th>
        <th>Nome do Cliente</th>
        <th>Instrutor</th>
        <th>Telefone</th>
        <th>Endereço</th>
        <th>Data de Inicio</th>
        <th>Observações</th>
        <th>Opções</th>
    </tr>
</thead>
    <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($clt-> id); ?></td>
            <td><?php echo e($clt-> nome); ?></td>
            <td><?php echo e($clt-> instrutor->nome); ?></td>
            <td><?php echo e($clt-> telefone); ?></td>
            <td><?php echo e($clt-> endereco); ?></td>
            <td><?php echo e($clt-> dataInicio); ?></td>
            <td><?php echo e($clt-> obs); ?></td>
            <td>
                <?php echo Form::open(['route'=> ['cliente.destroy',$clt->id], 'method'=>'delete']); ?>

                <?php echo Form::submit("Remover"); ?>

                <?php echo Form::close(); ?>           
            </td>
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>
</div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/cliente/index.blade.php ENDPATH**/ ?>