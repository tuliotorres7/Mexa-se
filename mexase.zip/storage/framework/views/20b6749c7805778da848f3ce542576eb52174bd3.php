<?php $__env->startSection('conteudo-view'); ?>
<?php if(session('success')): ?>
        <h3><?php echo e(session('success')['messages']); ?></h3>
<?php endif; ?>

<?php echo Form::open(['route' => 'presenca.store', 'method' => 'post','class'=>  'form-padrao']); ?>

        <?php echo $__env->make('templates.formulario.input',['input' => 'cliente_id', 'attributes'=>['placeholder' => 'ClienteID']], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        <?php echo $__env->make('templates.formulario.checkbox', ['label' => 'Radio'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        
        <?php echo $__env->make('templates.formulario.submit',['input' => 'Cadastrar'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo Form::close(); ?>



<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/presenca/index.blade.php ENDPATH**/ ?>