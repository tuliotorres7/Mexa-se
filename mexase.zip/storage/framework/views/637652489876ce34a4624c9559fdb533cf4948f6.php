<?php $__env->startSection('conteudo-view'); ?>
<?php if(session('success')): ?>
        <h3><?php echo e(session('success')['messages']); ?></h3>
<?php endif; ?>
<form  method="POST" action="<?php echo e(route('relatorioPresenca.search')); ?>" class="form-padrao">
<?php echo csrf_field(); ?>

<div class="row">        
<div class="col">
<label class>
<span>Data</span>
    <input type="date" name="data" placeholder="Data de inicio">
</label>
</div>
<div class="col">
<label class>
<span>Data Final</span>
    <input type="date" name="dataFim" placeholder="Data Final">
</label>
</div>
</div>
<div class ="row">
<div class="col">
<label class>
<span>Instrutor</span>
    <select name="user_id">
    <option value="">Instrutor</option>
    <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($key); ?>"><?php echo e($ul); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</label>
</div>
<div class="col">



<label class>
<span>Cliente</span>
    <select name="cliente_id">
    <option value="">Cliente</option>
    <?php $__currentLoopData = $cliente_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($key); ?>"><?php echo e($ul); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
</label>
</div>

</div>
<div class="row">
<div class="col">
<label class="submit">
    <input type="submit" value="Pesquisar">
</label>
</div>
</div>
</form>

<div class="row">
<div class=table-responsive-xl>
<table class="table table-hover">
<thead>
    <tr>
        <th>#</th>
        <th>Nome do Cliente</th>
        <th>Instrutor</th>
        <th>Dia</th>
        <th>Hora</th>
        <th>Status</th>
        
    </tr>

    <h1>Numero de Presenças: <?php if($presencas): ?><?php echo e(count($presencas)); ?><?php endif; ?></h1>
</thead>
<tbody>
        <?php if($presencas): ?>
        
        <?php $__currentLoopData = $presencas; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $prc): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($prc->id); ?></td>
            <td><?php echo e($prc->cliente->nome); ?></td>
            <td><?php echo e($prc->instrutor->nome); ?></td>

            <td><?php echo e($prc->data); ?></td>
            <td><?php echo e($prc->dataHora); ?></td>
            <td>
            <?php switch($prc->abertura):
    case (1): ?>
    <span class="abertura-icon"></span><?php break; ?>
    <?php case (0): ?>
    <span class="encerramento-icon"></span><?php break; ?>
<?php endswitch; ?>
    </td>
        </tr>
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
        <?php endif; ?>
    </tbody></table>
</div>
</div>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.masterAdmin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/relatorio/presenca.blade.php ENDPATH**/ ?>