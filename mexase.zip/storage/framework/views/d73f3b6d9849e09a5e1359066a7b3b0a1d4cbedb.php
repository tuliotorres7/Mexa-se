
   <?php echo Form::radio('abertura', '1', 1); ?>Abertura</br>
    <?php echo Form::radio('abertura', '0', 0); ?>Encerramento
<?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/templates/formulario/checkbox.blade.php ENDPATH**/ ?>