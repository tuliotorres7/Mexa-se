<label class="<?php echo e($class ?? null); ?>">
    <span><?php echo e($label ?? $input ?? "ERRO"); ?></span>
   
    <?php echo Form::password($input, $attributes); ?>

</label><?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/templates/formulario/password.blade.php ENDPATH**/ ?>