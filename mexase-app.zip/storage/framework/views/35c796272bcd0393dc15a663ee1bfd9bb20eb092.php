<?php $__env->startSection('conteudo-view'); ?>
htff
<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/relatorio/application.blade.php ENDPATH**/ ?>