<label class="<?php echo e($class ?? null); ?>">
    <span><?php echo e($label ?? $select ?? "ERRO"); ?></span>
    <?php echo Form::select($select , $data  ?? [] ); ?>

    
</label><?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/templates/formulario/select.blade.php ENDPATH**/ ?>