<label class="<?php echo e($class ?? null); ?> submit">
    
    <?php echo Form::submit($input); ?>

</label><?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/templates/formulario/submit.blade.php ENDPATH**/ ?>