<?php $__env->startSection('conteudo-view'); ?>
<?php if(session('success')): ?>
        <h3><?php echo e(session('success')['messages']); ?></h3>
<?php endif; ?>

<form action="<?php echo e(route('relatorio.search')); ?>" method="POST" class="form-padrao">
<?php echo csrf_field(); ?>

    <select name="type">

    <option value="">Instrutor</option>
    <?php $__currentLoopData = $user_list; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $ul): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
    <option value="<?php echo e($key); ?>"><?php echo e($ul); ?></option>
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </select>
<button type="submit" class="btn-primary">Pesquisar</button>
</form>


<table class="default-table">
<thead>
    <tr>
        <th>#</th>
        <th>Nome do Cliente</th>
        <th>Instrutor</th>
        <th>Opções</th>
    </tr>

</thead>
    <tbody>
        <?php $__currentLoopData = $clientes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $clt): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        <tr>
            <td><?php echo e($clt-> id); ?></td>
            <td><?php echo e($clt->nome); ?></td>
            <td><?php echo e($clt->instrutor->nome); ?></td>
            <td>
                <?php echo Form::open(['route'=> ['cliente.destroy',$clt->id], 'method'=>'delete']); ?>

                <?php echo Form::submit("Remover"); ?>

                <?php echo Form::close(); ?>            
            </td>
        </tr>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
    </tbody>
    </table>

<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/outras/relatorio.blade.php ENDPATH**/ ?>