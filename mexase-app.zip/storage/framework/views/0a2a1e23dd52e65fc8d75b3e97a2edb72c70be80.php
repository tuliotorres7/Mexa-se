<?php $__env->startSection('conteudo-view'); ?>
<?php if(session('success')): ?>
        <h3><?php echo e(session('success')['messages']); ?></h3>
<?php endif; ?>

<?php echo Form::open(['route' => 'presenca.store', 'method' => 'post','class'=>  'form-padrao']); ?>

<div class="row">        
<div class="col">
<label class="">
    <span>cliente_id</span>
    <input  placeholder="cliente ID" name="cliente_id" type="text" id="cliente_id" />
</label>

        </div>
        <div class="col">
        <?php echo $__env->make('templates.formulario.checkbox', ['label' => 'Radio'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
        </div>
        </div>
        
        <?php echo $__env->make('templates.formulario.submit',['input' => 'Assinar presença'], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>

        
    <video id="preview" autoplay playsinline></video>
    <script>
        let scanner = new Instascan.Scanner(
            {
                video: document.getElementById('preview') 
            }
        );
        scanner.addListener('scan', function(content) {
            //alert('Escaneou o conteudo: ' + content);
            document.getElementById('cliente_id').value = content;
        });
        
        Instascan.Camera.getCameras().then(cameras => 
        {
            if(cameras.length > 0){   
                    scanner.start(cameras[1]);
            } else {
                console.error("Não existe câmera no dispositivo!");
            }
        });
    </script>
<?php echo Form::close(); ?>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('templates.masterInstrutor', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tulio/Área de Trabalho/mexase-app/resources/views/Presenca/index.blade.php ENDPATH**/ ?>