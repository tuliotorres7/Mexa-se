<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface InstrutorRepository.
 *
 * @package namespace App\Repositories;
 */
interface InstrutorRepository extends RepositoryInterface
{
    //
}
