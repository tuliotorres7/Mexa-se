<?php

namespace App\Repositories;

use Prettus\Repository\Contracts\RepositoryInterface;

/**
 * Interface ClienteRepository.
 *
 * @package namespace App\Repositories;
 */
interface ClienteRepository extends RepositoryInterface
{
    //
}
